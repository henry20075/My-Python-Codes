import pygame
import sys
import colours
import detect

pygame.init()
pygame.mixer.init()

# ANIMATION SEQUENCES

animation_adventurer_idle1 = [pygame.image.load("images/adventurer/adventurer-idle-00.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-01.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-02.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-03.png")]
animation_adventurer_idle2 = [pygame.image.load("images/adventurer/adventurer-idle-2-00.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-2-01.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-2-02.png"),
                              pygame.image.load("images/adventurer/adventurer-idle-2-03.png")]
animation_adventurer_attack1 = [pygame.image.load("images/adventurer/adventurer-attack1-00.png"),
                                pygame.image.load("images/adventurer/adventurer-attack1-01.png"),
                                pygame.image.load("images/adventurer/adventurer-attack1-02.png"),
                                pygame.image.load("images/adventurer/adventurer-attack1-03.png"),
                                pygame.image.load("images/adventurer/adventurer-attack1-04.png")]
animation_adventurer_attack2 = [pygame.image.load("images/adventurer/adventurer-attack2-00.png"),
                                pygame.image.load("images/adventurer/adventurer-attack2-01.png"),
                                pygame.image.load("images/adventurer/adventurer-attack2-02.png"),
                                pygame.image.load("images/adventurer/adventurer-attack2-03.png"),
                                pygame.image.load("images/adventurer/adventurer-attack2-04.png"),
                                pygame.image.load("images/adventurer/adventurer-attack2-05.png")]
animation_adventurer_attack3 = [pygame.image.load("images/adventurer/adventurer-attack3-00.png"),
                                pygame.image.load("images/adventurer/adventurer-attack3-01.png"),
                                pygame.image.load("images/adventurer/adventurer-attack3-02.png"),
                                pygame.image.load("images/adventurer/adventurer-attack3-03.png"),
                                pygame.image.load("images/adventurer/adventurer-attack3-04.png"),
                                pygame.image.load("images/adventurer/adventurer-attack3-05.png")]
animation_adventurer_jump = [pygame.image.load("images/adventurer/adventurer-jump-00.png"),
                             pygame.image.load("images/adventurer/adventurer-jump-01.png"),
                             pygame.image.load("images/adventurer/adventurer-jump-02.png"),
                             pygame.image.load("images/adventurer/adventurer-jump-03.png")]
animation_adventurer_jump_attack1 = [pygame.image.load("images/adventurer/adventurer-air-attack1-00.png"),
                                     pygame.image.load("images/adventurer/adventurer-air-attack1-01.png"),
                                     pygame.image.load("images/adventurer/adventurer-air-attack1-02.png"),
                                     pygame.image.load("images/adventurer/adventurer-air-attack1-03.png")]
animation_adventurer_jump_attack2 = [pygame.image.load("images/adventurer/adventurer-air-attack2-00.png"),
                                     pygame.image.load("images/adventurer/adventurer-air-attack2-01.png"),
                                     pygame.image.load("images/adventurer/adventurer-air-attack2-02.png")]
animation_adventurer_run = [pygame.image.load("images/adventurer/adventurer-run-00.png"),
                            pygame.image.load("images/adventurer/adventurer-run-01.png"),
                            pygame.image.load("images/adventurer/adventurer-run-02.png"),
                            pygame.image.load("images/adventurer/adventurer-run-03.png"),
                            pygame.image.load("images/adventurer/adventurer-run-04.png"),
                            pygame.image.load("images/adventurer/adventurer-run-05.png")]

animation_slime_attack = [pygame.image.load("images/slime/slime-attack-0.png"),
                          pygame.image.load("images/slime/slime-attack-1.png"),
                          pygame.image.load("images/slime/slime-attack-2.png"),
                          pygame.image.load("images/slime/slime-attack-3.png"),
                          pygame.image.load("images/slime/slime-attack-4.png")]
animation_slime_jump_attack = [pygame.image.load("images/slime/slime-jumpattack-0.png"),
                               pygame.image.load("images/slime/slime-jumpattack-1.png"),
                               pygame.image.load("images/slime/slime-jumpattack-2.png"),
                               pygame.image.load("images/slime/slime-jumpattack-3.png"),
                               pygame.image.load("images/slime/slime-jumpattack-4.png")]
animation_slime_idle = [pygame.image.load("images/slime/slime-idle-0.png"),
                        pygame.image.load("images/slime/slime-idle-1.png"),
                        pygame.image.load("images/slime/slime-idle-2.png"),
                        pygame.image.load("images/slime/slime-idle-3.png")]
animation_slime_jump = [pygame.image.load("images/slime/slime-jump-0.png"),
                        pygame.image.load("images/slime/slime-jump-1.png"),
                        pygame.image.load("images/slime/slime-jump-2.png"),
                        pygame.image.load("images/slime/slime-jump-3.png")]
animation_slime_run = [pygame.image.load("images/slime/slime-move-0.png"),
                       pygame.image.load("images/slime/slime-move-1.png"),
                       pygame.image.load("images/slime/slime-move-2.png"),
                       pygame.image.load("images/slime/slime-move-3.png")]

animation_red_slime_attack = [pygame.image.load("images/red_slime/slime-attack-0.png"),
                              pygame.image.load("images/red_slime/slime-attack-1.png"),
                              pygame.image.load("images/red_slime/slime-attack-2.png"),
                              pygame.image.load("images/red_slime/slime-attack-3.png"),
                              pygame.image.load("images/red_slime/slime-attack-4.png")]
animation_red_slime_jump_attack = [pygame.image.load("images/red_slime/slime-jumpattack-0.png"),
                                   pygame.image.load("images/red_slime/slime-jumpattack-1.png"),
                                   pygame.image.load("images/red_slime/slime-jumpattack-2.png"),
                                   pygame.image.load("images/red_slime/slime-jumpattack-3.png"),
                                   pygame.image.load("images/red_slime/slime-jumpattack-4.png")]
animation_red_slime_idle = [pygame.image.load("images/red_slime/slime-idle-0.png"),
                            pygame.image.load("images/red_slime/slime-idle-1.png"),
                            pygame.image.load("images/red_slime/slime-idle-2.png"),
                            pygame.image.load("images/red_slime/slime-idle-3.png")]
animation_red_slime_jump = [pygame.image.load("images/red_slime/slime-jump-0.png"),
                            pygame.image.load("images/red_slime/slime-jump-1.png"),
                            pygame.image.load("images/red_slime/slime-jump-2.png"),
                            pygame.image.load("images/red_slime/slime-jump-3.png")]
animation_red_slime_run = [pygame.image.load("images/red_slime/slime-move-0.png"),
                           pygame.image.load("images/red_slime/slime-move-1.png"),
                           pygame.image.load("images/red_slime/slime-move-2.png"),
                           pygame.image.load("images/red_slime/slime-move-3.png")]

animation_knight_idle = [pygame.image.load("images/knight/knight-idle-0.png"),
                         pygame.image.load("images/knight/knight-idle-1.png"),
                         pygame.image.load("images/knight/knight-idle-2.png"),
                         pygame.image.load("images/knight/knight-idle-3.png"),
                         pygame.image.load("images/knight/knight-idle-4.png"),
                         pygame.image.load("images/knight/knight-idle-5.png"),
                         pygame.image.load("images/knight/knight-idle-6.png"),
                         pygame.image.load("images/knight/knight-idle-7.png"),
                         pygame.image.load("images/knight/knight-idle-8.png"),
                         pygame.image.load("images/knight/knight-idle-9.png"),
                         pygame.image.load("images/knight/knight-idle-10.png"),
                         pygame.image.load("images/knight/knight-idle-11.png"),
                         pygame.image.load("images/knight/knight-idle-12.png"),
                         pygame.image.load("images/knight/knight-idle-13.png"),
                         pygame.image.load("images/knight/knight-idle-14.png")]
animation_knight_attack = [pygame.image.load("images/knight/knight-attack-0.png"),
                           pygame.image.load("images/knight/knight-attack-1.png"),
                           pygame.image.load("images/knight/knight-attack-2.png"),
                           pygame.image.load("images/knight/knight-attack-3.png"),
                           pygame.image.load("images/knight/knight-attack-4.png")]
animation_knight_run = [pygame.image.load("images/knight/knight-run-0.png"),
                        pygame.image.load("images/knight/knight-run-1.png"),
                        pygame.image.load("images/knight/knight-run-2.png"),
                        pygame.image.load("images/knight/knight-run-3.png"),
                        pygame.image.load("images/knight/knight-run-4.png"),
                        pygame.image.load("images/knight/knight-run-5.png"),
                        pygame.image.load("images/knight/knight-run-6.png"),
                        pygame.image.load("images/knight/knight-run-7.png")]
animation_knight_jump = [pygame.image.load("images/knight/knight-jump-0.png"),
                         pygame.image.load("images/knight/knight-jump-1.png"),
                         pygame.image.load("images/knight/knight-jump-2.png"),
                         pygame.image.load("images/knight/knight-jump-3.png")]
animation_knight_jump_attack = [pygame.image.load("images/knight/knight-jumpattack-0.png"),
                                pygame.image.load("images/knight/knight-jumpattack-1.png"),
                                pygame.image.load("images/knight/knight-jumpattack-2.png"),
                                pygame.image.load("images/knight/knight-jumpattack-3.png")]

# IMAGE SURFACES

background_sunset = pygame.image.load("images/sunset.jpg")
background_dungeon = pygame.image.load("images/dungeon.jpg")
background_forest = pygame.image.load("images/forest.jpg")
background_meadow = pygame.image.load("images/meadowbetter.png")

icon_crossed_swords = pygame.image.load("images/crossed_swords.png")
icon_shield = pygame.image.load("images/shield.png")
icon_crown = pygame.image.load("images/crown.png")
icon_birdy = pygame.image.load("images/birdy.png")

object_crate = pygame.image.load("images/objects/crate.jpg")
object_plant_pot = pygame.image.load("images/objects/plant_pot.png")
object_table = pygame.image.load("images/objects/table.png")
object_wallpart = pygame.image.load("images/objects/wall_block2.png")
# SOUNDS

sound_ding = pygame.mixer.Sound("sounds/ding.wav")
sound_ding.set_volume(0.4)
sound_jump = pygame.mixer.Sound("sounds/jump.wav")
sound_jump.set_volume(0.4)
sound_ping = pygame.mixer.Sound("sounds/ping.wav")
sound_ping.set_volume(0.4)
sound_punch = pygame.mixer.Sound("sounds/punch.wav")
sound_punch.set_volume(0.4)

music_ark = "sounds/music_ark.mp3"
music_vessel = "sounds/music_vessel.mp3"

# CLASSES


class Window:

    def __init__(self):
        self.window = pygame.display.set_mode((900, 700))
        self.window_colour = colours.black
        self.window_filter = [None, None]
        self.delay = 50
        self.background_surface = None
        self.has_custom_title = False
        self.has_custom_icon = False
        pygame.display.set_caption("Untitled")
        pygame.display.set_icon(pygame.image.load("images/default_icon.png"))

        self.characters = []
        self.default_animation = [pygame.image.load("images/default_image.jpg")]

        self.objects = []
        self.default_image = pygame.image.load("images/default_image.jpg")

        self.triggers = []

        self.surface_height = 700

        self.music_playing = False

    def run(self):
        run = True
        while run:
            pygame.time.delay(self.delay)

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    sys.exit()

            self.window.fill(self.window_colour)
            print(pygame.mouse.get_pos())

            if self.background_surface is not None:
                self.window.blit(self.background_surface, (0, 0))

            character_count = 0
            for character in self.characters:
                # Processing triggers
                trigger_count = 0
                for trigger in self.triggers:
                    if trigger[0] == "CHARACTER" and trigger[1] == character[0]:  # Finding relevant trigger
                        # Processing indexes
                        secondary_subject_index = None
                        if trigger[2] == "COORDINATES":
                            subject_index = 1
                        elif trigger[2] == "X VELOCITY":
                            subject_index = 3
                        elif trigger[2] == "Y VELOCITY":
                            subject_index = 4
                        elif trigger[2] == "EFFECTED BY GRAVITY":
                            subject_index = 5
                        elif trigger[2] == "BORDER DIFFERENCE":
                            subject_index = 15
                        elif trigger[2] == "ACCELERATION":
                            subject_index = 6
                            secondary_subject_index = 2
                        elif trigger[2] == "MAX SPEED":
                            subject_index = 6
                            secondary_subject_index = 3
                        elif trigger[2] == "JUMP STRENGTH":
                            subject_index = 6
                            secondary_subject_index = 4
                        elif trigger[2] == "HAS ROTATIONAL ANIMATION":
                            subject_index = 11
                        elif trigger[2] == "CURRENT ROTATION":
                            subject_index = 12
                        elif trigger[2] == "CHARACTER SCALE":
                            subject_index = 13
                        elif trigger[2] == "IF CAN JUMP":
                            subject_index = 14
                        elif trigger[2] == "HEALTH":
                            subject_index = 16
                            secondary_subject_index = 1
                        elif trigger[2] == "MAX HEALTH":
                            subject_index = 16
                            secondary_subject_index = 2
                        elif trigger[2] == "HITBOX HEIGHT":
                            subject_index = 17
                            secondary_subject_index = 1
                        elif trigger[2] == "HITBOX WIDTH":
                            subject_index = 17
                            secondary_subject_index = 0
                        elif trigger[2] == "ATTACK RANGE":
                            subject_index = 17
                            secondary_subject_index = 2
                        elif trigger[2] == "ATTACK DAMAGE":
                            subject_index = 17
                            secondary_subject_index = 3
                        else:
                            subject_index = 18
                        secondary_result_index = None
                        if trigger[5] == "COORDINATES":
                            result_index = 1
                        elif trigger[5] == "X VELOCITY":
                            result_index = 3
                        elif trigger[5] == "Y VELOCITY":
                            result_index = 4
                        elif trigger[5] == "EFFECTED BY GRAVITY":
                            result_index = 5
                        elif trigger[5] == "BORDER DIFFERENCE":
                            result_index = 15
                        elif trigger[5] == "ACCELERATION":
                            result_index = 6
                            secondary_result_index = 2
                        elif trigger[5] == "MAX SPEED":
                            result_index = 6
                            secondary_result_index = 3
                        elif trigger[5] == "JUMP STRENGTH":
                            result_index = 6
                            secondary_result_index = 4
                        elif trigger[5] == "HAS ROTATIONAL ANIMATION":
                            result_index = 11
                        elif trigger[5] == "CURRENT ROTATION":
                            result_index = 12
                        elif trigger[5] == "CHARACTER SCALE":
                            result_index = 13
                        elif trigger[5] == "IF CAN JUMP":
                            result_index = 14
                        elif trigger[5] == "HEALTH":
                            result_index = 16
                            secondary_result_index = 1
                        elif trigger[5] == "MAX HEALTH":
                            result_index = 16
                            secondary_result_index = 2
                        elif trigger[5] == "HITBOX HEIGHT":
                            result_index = 17
                            secondary_result_index = 1
                        elif trigger[5] == "HITBOX WIDTH":
                            result_index = 17
                            secondary_result_index = 0
                        elif trigger[5] == "ATTACK RANGE":
                            result_index = 17
                            secondary_result_index = 2
                        elif trigger[5] == "ATTACK DAMAGE":
                            result_index = 17
                            secondary_result_index = 3
                        else:
                            result_index = 18
                        # Testing is requirement is met
                        if secondary_subject_index is None:
                            trigger_activated = False
                            if trigger[3] == "EQUALS" and character[subject_index] == trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS GREATER THAN" and character[subject_index] > trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS LESS THAN" and character[subject_index] < trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS NOT" and character[subject_index] != trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS GREATER THAN OR EQUAL TO" and character[subject_index] >= \
                                    trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS LESS THAN OR EQUAL TO" and character[subject_index] <= trigger[4]:
                                trigger_activated = True
                        else:
                            trigger_activated = False
                            if trigger[3] == "EQUALS" and \
                                    character[subject_index][secondary_subject_index] == trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS GREATER THAN" and \
                                    character[subject_index][secondary_subject_index] > trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS LESS THAN" and \
                                    character[subject_index][secondary_subject_index] < trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS NOT" and \
                                    character[subject_index][secondary_subject_index] != trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS GREATER THAN OR EQUAL TO" and \
                                    character[subject_index][secondary_subject_index] >= \
                                    trigger[4]:
                                trigger_activated = True
                            elif trigger[3] == "IS LESS THAN OR EQUAL TO" and \
                                    character[subject_index][secondary_subject_index] <= trigger[4]:
                                trigger_activated = True
                        # Performing operation
                        if trigger_activated:
                            if secondary_result_index is None:
                                if trigger[6] == "SET TO":
                                    self.characters[character_count][result_index] = trigger[7]
                                elif trigger[6] == "INCREASE BY":
                                    self.characters[character_count][result_index] += trigger[7]
                                elif trigger[6] == "DECREASE BY":
                                    self.characters[character_count][result_index] -= trigger[7]
                                elif trigger[6] == "MULTIPLY BY":
                                    self.characters[character_count][result_index] = \
                                        self.characters[character_count][result_index] * trigger[7]
                                elif trigger[6] == "DIVIDE BY":
                                    self.characters[character_count][result_index] = \
                                        self.characters[character_count][result_index] / trigger[7]
                            else:
                                if trigger[6] == "SET TO":
                                    self.characters[character_count][result_index][secondary_result_index] = trigger[7]
                                elif trigger[6] == "INCREASE BY":
                                    self.characters[character_count][result_index][secondary_result_index] += trigger[7]
                                elif trigger[6] == "DECREASE BY":
                                    self.characters[character_count][result_index][secondary_result_index] -= trigger[7]
                                elif trigger[6] == "MULTIPLY BY":
                                    self.characters[character_count][result_index][secondary_result_index] = \
                                        self.characters[character_count][result_index][secondary_result_index] * \
                                        trigger[7]
                                elif trigger[6] == "DIVIDE BY":
                                    self.characters[character_count][result_index][secondary_result_index] = \
                                        self.characters[character_count][result_index][secondary_result_index] / \
                                        trigger[7]
                            # Destroys trigger is necessary
                            if trigger[8]:
                                self.triggers.pop(trigger_count)
                    trigger_count += 1

                if character[18]:
                    # Getting character dimensions
                    image_width, image_height = character[2][0][0].get_rect().size

                    # Finding character midpoint
                    midpoint = character[1][0] + (image_width // 2)

                    # Calculates change in y velocity due to gravity
                    if character[5]:    # (If effected by gravity)
                        self.characters[character_count][4] += 1

                    # Detecting if character is on surface
                    if self.characters[character_count][1][1] == self.surface_height - image_height:
                        self.characters[character_count][8][4] = False
                        self.characters[character_count][8][3] = 1
                        self.characters[character_count][4] = 0

                    # Saving previous attack info
                    previous_attacking = character[7][4]

                    # Moves character
                    if character[6][0]:  # (If controlled by player)
                        if character[6][1] == "WASD":   # (If controlled by WASD)
                            if detect.w() and self.characters[character_count][1][1] == self.surface_height - \
                                    image_height and character[14]:
                                if character[19] is not None:
                                    character[19].play()
                                self.characters[character_count][4] -= character[6][4]
                                if character[8][5]:
                                    self.characters[character_count][8][4] = True
                            if detect.a():
                                self.characters[character_count][3] -= character[6][2]
                            elif self.characters[character_count][3] < character[6][2] * -1:
                                self.characters[character_count][3] += character[6][2]
                            elif self.characters[character_count][3] < 0:
                                self.characters[character_count][3] = 0
                            if detect.s():
                                self.characters[character_count][4] += 1
                            if detect.d():
                                self.characters[character_count][3] += character[6][2]
                            elif self.characters[character_count][3] > character[6][2]:
                                self.characters[character_count][3] -= character[6][2]
                            elif self.characters[character_count][3] > 0:
                                self.characters[character_count][3] = 0
                        else:
                            if detect.up() and self.characters[character_count][1][1] == self.surface_height - \
                                    image_height and character[14]:
                                if character[19] is not None:
                                    character[19].play()
                                self.characters[character_count][4] -= character[6][4]
                                if character[8][5]:
                                    self.characters[character_count][8][4] = True
                            if detect.left():
                                self.characters[character_count][3] -= character[6][2]
                            elif self.characters[character_count][3] < character[6][2] * -1:
                                self.characters[character_count][3] += character[6][2]
                            elif self.characters[character_count][3] < 0:
                                self.characters[character_count][3] = 0
                            if detect.down():
                                self.characters[character_count][4] += 1
                            if detect.right():
                                self.characters[character_count][3] += character[6][2]
                            elif self.characters[character_count][3] > character[6][2]:
                                self.characters[character_count][3] -= character[6][2]
                            elif self.characters[character_count][3] > 0:
                                self.characters[character_count][3] = 0
                    if self.characters[character_count][3] > character[6][3]:   # Corrects speed
                        correction_acceleration = character[6][2]
                        if self.characters[character_count][3] - character[6][3] >= correction_acceleration:
                            self.characters[character_count][3] = character[6][3]
                        else:
                            self.characters[character_count][3] -= correction_acceleration
                    elif self.characters[character_count][3] < character[6][3] * -1:
                        self.characters[character_count][3] = character[6][3] * -1
                    self.characters[character_count][1][0] += round(character[3])  # Changes x position
                    self.characters[character_count][1][1] += round(character[4])  # Changes y position
                    if self.characters[character_count][1][0] < 0 - character[15]:  # Corrects x location
                        self.characters[character_count][1][0] = 0 - character[15]
                        if self.characters[character_count][3] < 0 - character[15]:
                            self.characters[character_count][3] = 0
                    elif self.characters[character_count][1][0] > 900 - image_width + character[15]:
                        self.characters[character_count][1][0] = 900 - image_width + character[15]
                        if self.characters[character_count][3] > 0:
                            self.characters[character_count][3] = 0
                    # Corrects y location
                    if self.characters[character_count][1][1] > self.surface_height - image_height:
                        self.characters[character_count][1][1] = self.surface_height - image_height
                        if self.characters[character_count][4] > 0:
                            self.characters[character_count][4] = 0

                    # Detecting attack button
                    if ((character[7][5] == "LEFT CLICK" and pygame.mouse.get_pressed()[0]) or
                            (character[7][5] == "RIGHT CLICK" and pygame.mouse.get_pressed()[2]) or
                            (character[7][5] == "SPACE" and detect.space())) and not character[7][4]:
                        self.characters[character_count][7][4] = True

                    # Detecting character movement
                    if character[3] != 0 and character[10][5]:
                        self.characters[character_count][10][4] = True
                        if character[3] > 0:
                            self.characters[character_count][12] = "RIGHT"
                        else:
                            self.characters[character_count][12] = "LEFT"
                    elif character[10][5]:
                        self.characters[character_count][10][4] = False

                    # Performing current animation
                    if character[8][4]:
                        if character[7][4] and character[9][4]:
                            # Performing JUMP ATTACK animation
                            for frame in range(0, character[9][1]):
                                if frame * character[9][2] <= character[9][3] <= (frame + 1) * character[9][2]:
                                    current_frame = character[9][0][frame]
                                    if self.characters[character_count][12] == "LEFT":
                                        current_frame = pygame.transform.flip(current_frame, True, False)
                                        self.window.blit(current_frame, (character[1][0], character[1][1]))
                                    else:
                                        self.window.blit(current_frame, (character[1][0], character[1][1]))
                            self.characters[character_count][9][3] += 1
                            if self.characters[character_count][9][3] > self.characters[character_count][9][1] * \
                                    self.characters[character_count][9][2]:
                                self.characters[character_count][9][3] = 1
                                self.characters[character_count][7][4] = False
                        else:
                            # Performing JUMP animation
                            for frame in range(0, character[8][1]):
                                if frame * character[8][2] <= character[8][3] <= (frame + 1) * character[8][2]:
                                    current_frame = character[8][0][frame]
                                    if self.characters[character_count][12] == "LEFT":
                                        current_frame = pygame.transform.flip(current_frame, True, False)
                                        self.window.blit(current_frame, (character[1][0], character[1][1]))
                                    else:
                                        self.window.blit(current_frame, (character[1][0], character[1][1]))
                            self.characters[character_count][8][3] += 1
                            if self.characters[character_count][8][3] > self.characters[character_count][8][1] * \
                                    self.characters[character_count][8][2]:
                                self.characters[character_count][8][3] = self.characters[character_count][8][1] * \
                                    self.characters[character_count][8][2]
                    elif character[7][4]:
                        # Performing ATTACK animation
                        for frame in range(0, character[7][1]):
                            if frame * character[7][2] <= character[7][3] <= (frame + 1) * character[7][2]:
                                current_frame = character[7][0][frame]
                                if self.characters[character_count][12] == "LEFT":
                                    current_frame = pygame.transform.flip(current_frame, True, False)
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                                else:
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                        self.characters[character_count][7][3] += 1
                        if self.characters[character_count][7][3] > self.characters[character_count][7][1] * \
                                self.characters[character_count][7][2]:
                            self.characters[character_count][7][3] = 1
                            self.characters[character_count][7][4] = False
                    elif character[10][4] and character[10][5]:
                        # Performing RUNNING animation
                        for frame in range(0, character[10][1]):
                            if frame * character[10][2] <= character[10][3] <= (frame + 1) * character[10][2]:
                                current_frame = character[10][0][frame]
                                if self.characters[character_count][12] == "LEFT":
                                    current_frame = pygame.transform.flip(current_frame, True, False)
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                                else:
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                        self.characters[character_count][10][3] += 1
                        if self.characters[character_count][10][3] > self.characters[character_count][10][1] * \
                                self.characters[character_count][10][2]:
                            self.characters[character_count][10][3] = 1
                    else:
                        # Performing IDLE animation
                        for frame in range(0, character[2][1]):
                            if frame * character[2][2] <= character[2][3] <= (frame + 1) * character[2][2]:
                                current_frame = character[2][0][frame]
                                if self.characters[character_count][12] == "LEFT":
                                    current_frame = pygame.transform.flip(current_frame, True, False)
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                                else:
                                    self.window.blit(current_frame, (character[1][0], character[1][1]))
                        self.characters[character_count][2][3] += 1
                        if self.characters[character_count][2][3] > self.characters[character_count][2][1] * \
                                self.characters[character_count][2][2]:
                            self.characters[character_count][2][3] = 1

                    # Detecting hit character
                    if character[17][4]:
                        a_centre_x = character[1][0] + (image_width // 2)
                        a_centre_y = character[1][1] + (image_height // 2)
                        a1 = [a_centre_x - (character[17][0] // 2), a_centre_y - (character[17][1] // 2)]
                        a2 = [a_centre_x + (character[17][0] // 2), a_centre_y + (character[17][1] // 2)]
                        if character[17][5]:
                            hitbox_render = pygame.Surface((character[17][0], character[17][1]))
                            hitbox_render.set_alpha(128)
                            hitbox_render.fill(colours.gold)
                            self.window.blit(hitbox_render, (a1[0], a1[1]))
                        knockback_multiplier = -1
                        if character[12] == "LEFT":
                            attack_a = [a1[0] - character[17][2], a1[1]]
                            attack_b = a2
                        else:
                            attack_a = a1
                            attack_b = [a2[0] + character[17][2], a2[1]]
                            knockback_multiplier = 1
                        if character[17][6]:
                            attack_range_render = pygame.Surface((character[17][2], character[17][1]))
                            attack_range_render.set_alpha(128)
                            attack_range_render.fill(colours.firebrick)
                            if character[12] == "LEFT":
                                self.window.blit(attack_range_render, (attack_a[0], attack_a[1]))
                            else:
                                self.window.blit(attack_range_render, (a2[0], attack_a[1]))
                        target_character_count = 0
                        for target_character in self.characters:
                            if target_character[0] != character[0] and target_character[17][4] and target_character[18]:
                                # Getting target character dimensions
                                b_image_width, b_image_height = target_character[2][0][0].get_rect().size
                                b_centre_x = target_character[1][0] + (b_image_width // 2)
                                b_centre_y = target_character[1][1] + (b_image_height // 2)
                                b1 = [b_centre_x - (target_character[17][0] // 2), b_centre_y -
                                      (target_character[17][1] // 2)]
                                b2 = [b_centre_x + (target_character[17][0] // 2), b_centre_y +
                                      (target_character[17][1] // 2)]
                                if character[7][4] and attack_a[0] <= b2[0] and attack_b[0] >= b1[0] and \
                                        attack_a[1] <= b2[1] and attack_b[1] >= b1[1] and not previous_attacking:
                                    knockback_ratio = character[17][3] / target_character[16][2]
                                    knockback_base = 100
                                    knockback_amount = round(knockback_base * knockback_multiplier * knockback_ratio)
                                    self.characters[target_character_count][3] += knockback_amount
                                    self.characters[target_character_count][4] -= 150 * knockback_ratio
                                    self.characters[target_character_count][16][1] -= character[17][3]
                                    if character[20] is not None:
                                        character[20].play()
                            target_character_count += 1

                    # Detecting hit object
                    if character[17][4]:
                        a_centre_x = character[1][0] + (image_width // 2)
                        a_centre_y = character[1][1] + (image_height // 2)
                        a1 = [a_centre_x - (character[17][0] // 2), a_centre_y - (character[17][1] // 2)]
                        a2 = [a_centre_x + (character[17][0] // 2), a_centre_y + (character[17][1] // 2)]
                        knockback_multiplier = -1
                        if character[12] == "LEFT":
                            attack_a = [a1[0] - character[17][2], a1[1]]
                            attack_b = a2
                        else:
                            attack_a = a1
                            attack_b = [a2[0] + character[17][2], a2[1]]
                            knockback_multiplier = 1
                        target_object_count = 0
                        for target_object in self.objects:
                            if target_object[0] != character[0] and target_object[7]:
                                # Getting target character dimensions
                                object_width, object_height = target_object[2].get_rect().size
                                b1 = target_object[1]
                                b2 = [target_object[1][0] + object_width, target_object[1][1] + object_height]
                                if character[7][4] and attack_a[0] <= b2[0] and attack_b[0] >= b1[0] and \
                                        attack_a[1] <= b2[1] and attack_b[1] >= b1[1] and not previous_attacking:
                                    knockback_base = 10
                                    knockback_amount = round(knockback_base * knockback_multiplier)
                                    self.objects[target_object_count][3] += knockback_amount
                                    self.objects[target_object_count][4] -= 15
                                    if character[20] is not None:
                                        character[20].play()
                            target_object_count += 1

                    # Correcting character health
                    if character[16][1] < 0:
                        self.characters[character_count][16][1] = 0
                    elif character[16][1] > character[16][2]:
                        self.characters[character_count][16][1] = character[16][2]

                    # Drawing character health bars
                    if character[16][0]:
                        box_x = midpoint - (character[16][3] // 2)
                        box_y = character[1][1] - (character[16][4] * 2)
                        pygame.draw.rect(self.window, character[16][5], (box_x, box_y, character[16][3],
                                                                         character[16][4]))
                        health_ratio = character[16][1] / character[16][2]
                        outline_width = character[16][4] // 4
                        bar_width = round((character[16][3] - (2 * outline_width)) * health_ratio)
                        bar_height = character[16][4] - (2 * outline_width)
                        negative_bar_width = (character[16][3] - (2 * outline_width)) - bar_width
                        if character[16][1] > 0:
                            pygame.draw.rect(self.window, character[16][6], (box_x + outline_width, box_y +
                                                                             outline_width, bar_width, bar_height))
                        if negative_bar_width > 0:
                            pygame.draw.rect(self.window, character[16][7], (box_x + outline_width + bar_width, box_y +
                                                                             outline_width, negative_bar_width,
                                                                             bar_height))

                character_count += 1

            object_count = 0
            for current_object in self.objects:
                # Processing triggers
                trigger_count = 0
                for trigger in self.triggers:
                    if trigger[0] == "OBJECT" and trigger[1] == current_object[0]:  # Finding relevant trigger
                        # Processing indexes
                        if trigger[2] == "COORDINATES":
                            subject_index = 1
                        elif trigger[2] == "X VELOCITY":
                            subject_index = 3
                        elif trigger[2] == "Y VELOCITY":
                            subject_index = 4
                        elif trigger[2] == "EFFECTED BY GRAVITY":
                            subject_index = 5
                        elif trigger[2] == "BORDER DIFFERENCE":
                            subject_index = 6
                        else:
                            subject_index = 7
                        if trigger[5] == "COORDINATES":
                            result_index = 1
                        elif trigger[5] == "X VELOCITY":
                            result_index = 3
                        elif trigger[5] == "Y VELOCITY":
                            result_index = 4
                        elif trigger[5] == "EFFECTED BY GRAVITY":
                            result_index = 5
                        elif trigger[5] == "BORDER DIFFERENCE":
                            result_index = 6
                        else:
                            result_index = 7
                        # Testing is requirement is met
                        trigger_activated = False
                        if trigger[3] == "EQUALS" and current_object[subject_index] == trigger[4]:
                            trigger_activated = True
                        elif trigger[3] == "IS GREATER THAN" and current_object[subject_index] > trigger[4]:
                            trigger_activated = True
                        elif trigger[3] == "IS LESS THAN" and current_object[subject_index] < trigger[4]:
                            trigger_activated = True
                        elif trigger[3] == "IS NOT" and current_object[subject_index] != trigger[4]:
                            trigger_activated = True
                        elif trigger[3] == "IS GREATER THAN OR EQUAL TO" and current_object[subject_index] >= \
                                trigger[4]:
                            trigger_activated = True
                        elif trigger[3] == "IS LESS THAN OR EQUAL TO" and current_object[subject_index] <= trigger[4]:
                            trigger_activated = True
                        # Performing operation
                        if trigger_activated:
                            if trigger[6] == "SET TO":
                                self.objects[object_count][result_index] = trigger[7]
                            elif trigger[6] == "INCREASE BY":
                                self.objects[object_count][result_index] += trigger[7]
                            elif trigger[6] == "DECREASE BY":
                                self.objects[object_count][result_index] -= trigger[7]
                            elif trigger[6] == "MULTIPLY BY":
                                self.objects[object_count][result_index] = self.objects[object_count][result_index] * \
                                                                           trigger[7]
                            elif trigger[6] == "DIVIDE BY":
                                self.objects[object_count][result_index] = self.objects[object_count][result_index] / \
                                                                           trigger[7]
                            # Destroys trigger is necessary
                            if trigger[8]:
                                self.triggers.pop(trigger_count)
                    trigger_count += 1

                if current_object[7]:
                    # Getting object dimensions
                    image_width, image_height = current_object[2].get_rect().size

                    # Calculates change in y velocity due to gravity
                    if current_object[5]:  # (If effected by gravity)
                        self.objects[object_count][4] += 1

                    if current_object[3] > 1:   # Changes x velocity
                        self.objects[object_count][3] -= 1
                    elif current_object[3] < -1:
                        self.objects[object_count][3] += 1
                    else:
                        self.objects[object_count][3] = 0

                    self.objects[object_count][1][0] += round(current_object[3])  # Changes x position
                    self.objects[object_count][1][1] += round(current_object[4])  # Changes y position
                    if self.objects[object_count][1][0] < 0 - current_object[6]:  # Corrects x location
                        self.objects[object_count][1][0] = 0 - current_object[6]
                        if self.objects[object_count][3] < 0:
                            self.objects[object_count][3] = 0
                    elif self.objects[object_count][1][0] > 900 - image_width + current_object[6]:
                        self.objects[object_count][1][0] = 900 - image_width + current_object[6]
                        if self.objects[object_count][3] > 0:
                            self.objects[object_count][3] = 0
                    if self.objects[object_count][1][1] > self.surface_height - image_height:  # Corrects y location
                        self.objects[object_count][1][1] = self.surface_height - image_height
                        if self.objects[object_count][4] > 0:
                            self.objects[object_count][4] = 0

                    self.window.blit(current_object[2], current_object[1])

            # Applying window filter
            if self.window_filter[0] is not None:
                window_filter = pygame.Surface((900, 700))
                window_filter.set_alpha(self.window_filter[1])
                window_filter.fill(self.window_filter[0])
                self.window.blit(window_filter, (0, 0))

            pygame.display.update()

    def play_music(self, music):
        if not self.music_playing:
            pygame.mixer.music.load(music)
            pygame.mixer.music.set_volume(0.2)
            pygame.mixer.music.play(-1)
            self.music_playing = True

    def new_trigger(self, entity_type, name, subject, subject_trigger, subject_value, result_subject,
                    result_operation, result_value, destructive=True):
        if entity_type == "CHARACTER" or entity_type == "OBJECT":
            if (entity_type == "CHARACTER" and (subject == "COORDINATES" or subject == "X VELOCITY" or
                                                subject == "Y VELOCITY" or subject == "EFFECTED BY GRAVITY" or
                                                subject == "ACCELERATION" or subject == "MAX SPEED" or
                                                subject == "JUMP STRENGTH" or subject == "HAS ROTATIONAL ANIMATION" or
                                                subject == "CURRENT ROTATION" or subject == "CHARACTER SCALE" or
                                                subject == "IF CAN JUMP" or subject == "BORDER DIFFERENCE" or
                                                subject == "HEALTH" or subject == "MAX HEALTH" or
                                                subject == "HITBOX HEIGHT" or subject == "HITBOX WIDTH" or
                                                subject == "ATTACK RANGE" or subject == "ATTACK DAMAGE" or
                                                subject == "IF PRESENT")) or (entity_type == "OBJECT" and
                                                                              (subject == "COORDINATES" or
                                                                               subject == "X VELOCITY" or
                                                                               subject == "Y VELOCITY" or
                                                                               subject == "EFFECTED BY GRAVITY" or
                                                                               subject == "BORDER DIFFERENCE" or
                                                                               subject == "IF PRESENT")):
                if (entity_type == "CHARACTER" and (result_subject == "COORDINATES" or result_subject == "X VELOCITY" or
                                                    result_subject == "Y VELOCITY" or
                                                    result_subject == "EFFECTED BY GRAVITY" or
                                                    result_subject == "ACCELERATION" or result_subject == "MAX SPEED" or
                                                    result_subject == "JUMP STRENGTH" or
                                                    result_subject == "HAS ROTATIONAL ANIMATION" or
                                                    result_subject == "CURRENT ROTATION" or
                                                    result_subject == "CHARACTER SCALE" or
                                                    result_subject == "IF CAN JUMP" or
                                                    result_subject == "BORDER DIFFERENCE" or
                                                    result_subject == "HEALTH" or result_subject == "MAX HEALTH" or
                                                    result_subject == "HITBOX HEIGHT" or
                                                    result_subject == "HITBOX WIDTH" or
                                                    result_subject == "ATTACK RANGE" or
                                                    result_subject == "ATTACK DAMAGE" or
                                                    result_subject == "IF PRESENT")) or (entity_type == "OBJECT" and
                                                                                         (result_subject ==
                                                                                          "COORDINATES" or
                                                                                          result_subject == "X VELOCITY"
                                                                                          or result_subject ==
                                                                                          "Y VELOCITY" or
                                                                                          result_subject ==
                                                                                          "EFFECTED BY GRAVITY" or
                                                                                          result_subject ==
                                                                                          "BORDER DIFFERENCE" or
                                                                                          result_subject ==
                                                                                          "IF PRESENT")):
                    if subject_trigger == "EQUALS" or subject_trigger == "IS GREATER THAN" or \
                            subject_trigger == "IS LESS THAN" or subject_trigger == "IS NOT" or \
                            subject_trigger == "IS GREATER THAN OR EQUAL TO" or \
                            subject_trigger == "IS LESS THAN OR EQUAL TO":
                        if result_operation == "SET TO" or result_operation == "INCREASE BY" or result_operation == \
                                "DECREASE BY" or result_operation == "MULTIPLY BY" or result_operation == "DIVIDE BY":
                            self.triggers.append([entity_type, name, subject, subject_trigger, subject_value,
                                                  result_subject, result_operation, result_value, destructive])
                        else:
                            print("Result operation not found")
                    else:
                        print("Subject trigger", subject_trigger, "not found")
                else:
                    print("Result subject", result_subject, "not found for", entity_type)
            else:
                print("Subject", subject, "not found for", entity_type)
        else:
            print("'entity_type' must be either 'CHARACTER' or 'OBJECT'")

    def new_object(self, name):
        dupe_detected = False
        for current_object in self.objects:
            if current_object[0] == name:
                dupe_detected = True
        if not dupe_detected:
            # Each object has an array containing [0 - name, 1 - coordinates, 2 - image, 3 - x velocity, 4 - y velocity,
            # 5 - effected by gravity, 6 - border difference, 7 - if present]
            self.objects.append([name, [0, 0], self.default_image, 0, 0, False, 0, True])
        else:
            print("Two objects cannot have the same name/identifier!")

    def set_object_presence(self, name, boolean):
        if boolean is True or boolean is False:
            object_count = 0
            for current_object in self.objects:
                if current_object[0] == name:
                    self.objects[object_count][7] = boolean
                object_count += 1
        else:
            print("'boolean' must be either 'True' or 'False'")

    def set_object_effected_by_gravity(self, name, boolean):
        if boolean is not False and boolean is not True:
            print("'True' or 'False' required for changing effect of gravity")
        else:
            object_count = 0
            for current_object in self.objects:
                if current_object[0] == name:
                    self.objects[object_count][5] = boolean
                object_count += 1

    def set_object_image(self, name, image_surface):
        object_count = 0
        for current_object in self.objects:
            if current_object[0] == name:
                self.objects[object_count][2] = image_surface
            object_count += 1

    def set_object_scale(self, name, scale_multiplier=1):
        if scale_multiplier % 1 == 0:
            object_count = 0
            for current_object in self.objects:
                if current_object[0] == name:
                    image_width, image_height = self.objects[object_count][2].get_rect().size
                    self.objects[object_count][2] = pygame.transform.scale(self.objects[object_count][2],
                                                                           (image_width * scale_multiplier,
                                                                            image_height * scale_multiplier))
                object_count += 1
        else:
            print("Integer (whole number) value required")

    def set_object_position(self, name, x, y):
        if x % 1 == 0 and y % 1 == 0:
            object_count = 0
            for current_object in self.objects:
                if current_object[0] == name:
                    self.objects[object_count][1] = [x, y]
                object_count += 1
        else:
            print("x and y must both be integer values (whole numbers)")

    def set_object_border_difference(self, name, value):
        if value % 1 == 0:
            object_count = 0
            for current_object in self.objects:
                if current_object[0] == name:
                    self.objects[object_count][6] = value
                object_count += 1
        else:
            print("'value' must be an integer (whole number)")

    def new_character(self, name):
        dupe_detected = False
        for character in self.characters:
            if character[0] == name:
                dupe_detected = True
        # Each character has an array containing [0 - name, 1 - coordinates, 2 - [0 - animation, 1 - animation frames,
        # 2 - animation delay, 3 - animation count], 3 - x velocity, 4 - y velocity, 5 - effected by gravity,
        # 6 - [0 - has player movement, 1 - movement type, 2 - movement acceleration, 3 - max speed, 4 - jump strength],
        # 7 - [0 - attack animation, 1 - attack animation frames, 2 - attack animation delay,
        # 3 - attack animation count, 4 - if attacking, 5 - attack button], 8 - [0 - jump animation,
        # 1 - jump animation frames, 2 - jump animation delay, 3 - jump animation count, 4 - if jumping,
        # 5 - has jump animation enabled], 9 - [0 - jump attack animation, 1 - jump attack animation frames,
        # 2 - jump attack animation delay, 3 - jump attack animation count, 4 - has jump attack enabled],
        # 10 - [0 - run animation, 1 - run animation frames, 2 - run animation delay, 3 - run animation count,
        # 4 - if running, 5 - has running enabled], 11 - has rotational animation enabled, 12 - current rotation,
        # 13 - character scale, 14 - if can jump, 15 - border difference, 16 - [0 - if health enabled, 1 - health,
        # 2 - max health, 3 - box width, 4 - box height, 5 - box colour, 6 - bar colour, 7 - negative colour],
        # 17 - [0 - hitbox width, 1 - hitbox height, 2 - attack range, 3 - attack damage, 4 - if attack enabled,
        # 5 - if show hitbox, 6 - if show attack range], 18 - if present, 19 - jump sound, 20 - attack sound]
        if not dupe_detected:
            self.characters.append([name, [0, 0], [self.default_animation, 1, 1, 1], 0, 0, False, [False, None, 1, 10,
                                    22], [self.default_animation, 1, 1, 1, False, None],
                                    [self.default_animation, 1, 1, 1, False, False],
                                    [self.default_animation, 1, 1, 1, False],
                                    [self.default_animation, 1, 1, 1, False, False], False, "RIGHT", 1, False, 0,
                                    [False, 0, 0, 20, 4, colours.grey, colours.lime, colours.red],
                                    [0, 0, 0, 0, False, False, False], True, None, None])
        else:
            print("Two characters cannot have the same name/identifier!")

    def set_character_attack_sound(self, name, sound):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                self.characters[character_count][20] = sound
            character_count += 1

    def set_character_jump_sound(self, name, sound):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                self.characters[character_count][19] = sound
            character_count += 1

    def set_character_presence(self, name, boolean):
        if boolean is True or boolean is False:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][18] = boolean
                character_count += 1
        else:
            print("'boolean' must be either 'True' or 'False'")

    def set_character_attack_function(self, name, hitbox_width, hitbox_height, attack_range, attack_damage,
                                      display_hitbox=False, display_attack_range=False):
        if hitbox_width % 1 == 0 and hitbox_height % 1 == 0 and attack_range % 1 == 0 and attack_damage % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][17][0] = hitbox_width
                    self.characters[character_count][17][1] = hitbox_height
                    self.characters[character_count][17][2] = attack_range
                    self.characters[character_count][17][3] = attack_damage
                    self.characters[character_count][17][4] = True
                    self.characters[character_count][17][5] = display_hitbox
                    self.characters[character_count][17][6] = display_attack_range
                character_count += 1
        else:
            print("'hitbox_width', 'hitbox_height', 'attack_range' and 'attack_damage' must be integers "
                  "(whole numbers)")

    def set_character_health_colours(self, name, positive_colour, negative_colour, box_colour):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                self.characters[character_count][16][6] = positive_colour
                self.characters[character_count][16][7] = negative_colour
                self.characters[character_count][16][5] = box_colour
            character_count += 1

    def set_character_health_scale(self, name, scale_multiplier=1):
        if scale_multiplier > 0 and scale_multiplier % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][16][3] = self.characters[character_count][16][3] * scale_multiplier
                    self.characters[character_count][16][4] = self.characters[character_count][16][4] * scale_multiplier
                character_count += 1
        else:
            print("'scale_multiplier' must be above 0 and an integer (whole number)")

    def set_character_health(self, name, health, max_health):
        if health % 1 == 0 and max_health % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][16][0] = True
                    self.characters[character_count][16][1] = health
                    self.characters[character_count][16][2] = max_health
                character_count += 1
        else:
            print("Both 'health' and 'max_health' must be integers (whole numbers)")

    def set_character_border_difference(self, name, value):
        if value % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][15] = value
                character_count += 1
        else:
            print("'value' must be an integer (whole number)")

    def set_character_rotational_animation(self, name, boolean):
        if boolean is True or boolean is False:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][11] = boolean
                character_count += 1
        else:
            print("'boolean' must be either 'True' or 'False'")

    def set_character_running_animation(self, name, animation_sequence, animation_delay):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                scaled_animation = []
                for animation in animation_sequence:
                    image_width, image_height = animation.get_rect().size
                    scaled_animation.append(pygame.transform.scale(animation, (image_width *
                                            self.characters[character_count][13], image_height *
                                            self.characters[character_count][13])))
                self.characters[character_count][10][0] = scaled_animation
                self.characters[character_count][10][1] = len(animation_sequence)
                self.characters[character_count][10][2] = animation_delay
                self.characters[character_count][10][3] = 1
                self.characters[character_count][10][5] = True
            character_count += 1

    def set_character_jump_animation(self, name, animation_sequence, animation_delay):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                scaled_animation = []
                for animation in animation_sequence:
                    image_width, image_height = animation.get_rect().size
                    scaled_animation.append(pygame.transform.scale(animation, (image_width *
                                            self.characters[character_count][13], image_height *
                                            self.characters[character_count][13])))
                self.characters[character_count][8][0] = scaled_animation
                self.characters[character_count][8][1] = len(animation_sequence)
                self.characters[character_count][8][2] = animation_delay
                self.characters[character_count][8][3] = 1
                self.characters[character_count][8][5] = True
                self.characters[character_count][14] = True
            character_count += 1

    def set_character_movement(self, name, boolean, movement_type, acceleration, max_speed):
        if (boolean is True or boolean is False) and acceleration % 1 == 0 and max_speed % 1 == 0 and \
                (movement_type == "WASD" or movement_type == "ARROWS"):
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][6][0] = boolean
                    self.characters[character_count][6][1] = movement_type
                    self.characters[character_count][6][2] = acceleration
                    self.characters[character_count][6][3] = max_speed
                character_count += 1
        else:
            print("'boolean' must be 'True' or 'False', speed and max_speed must be whole numbers and 'movement_type' "
                  "must be 'WASD' or 'ARROWS'")

    def set_character_jump_strength(self, name, value):
        if value % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][6][4] = value
                character_count += 1
        else:
            print("'value' must be an integer (whole number)")

    def set_character_attack_button(self, name, button):
        if button == "RIGHT CLICK" or button == "LEFT CLICK" or button == "SPACE":
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][7][5] = button
                character_count += 1
        else:
            print("'button' must be either 'RIGHT CLICK' or 'LEFT CLICK' or 'SPACE'")

    def set_character_idle_animation(self, name, animation_sequence, animation_delay):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                scaled_animation = []
                for animation in animation_sequence:
                    image_width, image_height = animation.get_rect().size
                    scaled_animation.append(pygame.transform.scale(animation, (image_width *
                                            self.characters[character_count][13], image_height *
                                            self.characters[character_count][13])))
                self.characters[character_count][2][0] = scaled_animation
                self.characters[character_count][2][1] = len(animation_sequence)
                self.characters[character_count][2][2] = animation_delay
                self.characters[character_count][2][3] = 1
            character_count += 1

    def set_character_attack_animation(self, name, animation_sequence, animation_delay):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                scaled_animation = []
                for animation in animation_sequence:
                    image_width, image_height = animation.get_rect().size
                    scaled_animation.append(pygame.transform.scale(animation, (image_width *
                                            self.characters[character_count][13], image_height *
                                            self.characters[character_count][13])))
                self.characters[character_count][7][0] = scaled_animation
                self.characters[character_count][7][1] = len(animation_sequence)
                self.characters[character_count][7][2] = animation_delay
                self.characters[character_count][7][3] = 1
            character_count += 1

    def set_character_jump_attack_animation(self, name, animation_sequence, animation_delay):
        character_count = 0
        for character in self.characters:
            if character[0] == name:
                scaled_animation = []
                for animation in animation_sequence:
                    image_width, image_height = animation.get_rect().size
                    scaled_animation.append(pygame.transform.scale(animation, (image_width *
                                            self.characters[character_count][13], image_height *
                                            self.characters[character_count][13])))
                self.characters[character_count][9][0] = scaled_animation
                self.characters[character_count][9][1] = len(animation_sequence)
                self.characters[character_count][9][2] = animation_delay
                self.characters[character_count][9][3] = 1
                self.characters[character_count][9][4] = True
            character_count += 1

    def set_character_scale(self, name, scale_multiplier=1):
        if scale_multiplier % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    # Scaling IDLE animation
                    animation_count = 0
                    for animation in character[2][0]:
                        image_width, image_height = animation.get_rect().size
                        self.characters[character_count][2][0][animation_count] = pygame.transform.scale(
                            self.characters[character_count][2][0][animation_count], (image_width * scale_multiplier,
                                                                                      image_height * scale_multiplier))
                        animation_count += 1
                    # Scaling ATTACK animation
                    animation_count = 0
                    for animation in character[7][0]:
                        image_width, image_height = animation.get_rect().size
                        self.characters[character_count][7][0][animation_count] = pygame.transform.scale(
                            self.characters[character_count][7][0][animation_count], (image_width * scale_multiplier,
                                                                                      image_height * scale_multiplier))
                        animation_count += 1
                    # Scaling JUMP animation
                    animation_count = 0
                    for animation in character[8][0]:
                        image_width, image_height = animation.get_rect().size
                        self.characters[character_count][8][0][animation_count] = pygame.transform.scale(
                            self.characters[character_count][8][0][animation_count], (image_width * scale_multiplier,
                                                                                      image_height * scale_multiplier))
                        animation_count += 1
                    # Scaling JUMP ATTACK animation
                    animation_count = 0
                    for animation in character[9][0]:
                        image_width, image_height = animation.get_rect().size
                        self.characters[character_count][9][0][animation_count] = pygame.transform.scale(
                            self.characters[character_count][9][0][animation_count], (image_width * scale_multiplier,
                                                                                      image_height * scale_multiplier))
                        animation_count += 1
                    # Scaling RUNNING animation
                    animation_count = 0
                    for animation in character[10][0]:
                        image_width, image_height = animation.get_rect().size
                        self.characters[character_count][10][0][animation_count] = pygame.transform.scale(
                            self.characters[character_count][10][0][animation_count], (image_width * scale_multiplier,
                                                                                       image_height * scale_multiplier))
                        animation_count += 1
                    self.characters[character_count][13] = scale_multiplier
                character_count += 1
        else:
            print("Integer (whole number) value required")

    def set_character_position(self, name, x, y):
        if x % 1 == 0 and y % 1 == 0:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][1] = [x, y]
                character_count += 1
        else:
            print("x and y must both be integer values (whole numbers)")

    def set_character_effected_by_gravity(self, name, boolean):
        if boolean is not False and boolean is not True:
            print("'True' or 'False' required for changing effect of gravity")
        else:
            character_count = 0
            for character in self.characters:
                if character[0] == name:
                    self.characters[character_count][5] = boolean
                character_count += 1

    def set_surface_height(self, value):
        if value % 1 == 0:
            self.surface_height = value
        else:
            print("Value for surface height must be an integer (whole number)")

    def set_filter(self, colour, alpha):
        if 0 <= alpha <= 255:
            if alpha % 1 == 0:
                self.window_filter = [colour, alpha]
            else:
                print("'alpha' must be and integer (whole number)")
        else:
            print("'alpha' must be between 0 and 255")

    def set_background(self, image_surface):
        self.background_surface = image_surface

    def set_colour(self, colour):
        self.window_colour = colour

    def set_update_delay(self, value):
        self.delay = value

    def set_title(self, string):
        pygame.display.set_caption(string)
        self.has_custom_title = True

    def set_icon(self, image_surface):
        pygame.display.set_icon(image_surface)
        self.has_custom_icon = True

    def get_colour(self):
        return self.window_colour

    def get_update_delay(self):
        return self.delay
