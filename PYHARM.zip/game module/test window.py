import pygame
import sys
import colours

window = pygame.display.set_mode((900, 900))

default = pygame.image.load("images/default_image.jpg")
default = pygame.transform.scale(default, (500, 500))

run = True
while run:
    pygame.time.delay(50)

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            sys.exit()

    window.fill(colours.black)

    window.blit(default, (200, 200))

    pygame.display.update()
