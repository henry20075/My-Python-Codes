import game
import colours
import time
# IMPORTS - Probably don't need to edit that stuff :)



window = game.Window()
window.set_background(game.background_meadow)
def walls4l1():
    window.new_object("Wall Block1")
    window.set_object_image("Wall Block1", game.object_wallpart)
    window.set_object_position("Wall Block1", 512, 660)

    window.new_object("Wall Block2")
    window.set_object_image("Wall Block2", game.object_wallpart)
    window.set_object_position("Wall Block2", 512, 620)

    window.new_object("Wall Block3")
    window.set_object_image("Wall Block3", game.object_wallpart)
    window.set_object_position("Wall Block3", 512, 580)

    window.new_object("Wall Block4")
    window.set_object_image("Wall Block4", game.object_wallpart)
    window.set_object_position("Wall Block4", 512, 540)

    window.new_object("Wall Block5")
    window.set_object_image("Wall Block5", game.object_wallpart)
    window.set_object_position("Wall Block5", 512, 500)

    window.new_object("Wall Block6")
    window.set_object_image("Wall Block6", game.object_wallpart)
    window.set_object_position("Wall Block6", 512, 460)

    window.new_object("Wall Block7")
    window.set_object_image("Wall Block7", game.object_wallpart)
    window.set_object_position("Wall Block7", 512, 420)

    window.new_object("Wall Block8")
    window.set_object_image("Wall Block8", game.object_wallpart)
    window.set_object_position("Wall Block8", 512, 300)

    window.new_object("Wall Block9")
    window.set_object_image("Wall Block9", game.object_wallpart)
    window.set_object_position("Wall Block9", 512, 260)

    window.new_object("Wall Blocka")
    window.set_object_image("Wall Blocka", game.object_wallpart)
    window.set_object_position("Wall Blocka", 512, 220)

    window.new_object("Wall Blockb")
    window.set_object_image("Wall Blockb", game.object_wallpart)
    window.set_object_position("Wall Blockb", 512, 180)

    window.new_object("Wall Blockc")
    window.set_object_image("Wall Blockc", game.object_wallpart)
    window.set_object_position("Wall Blockc", 512, 140)

    window.new_object("Wall Blockd")
    window.set_object_image("Wall Blockd", game.object_wallpart)
    window.set_object_position("Wall Blockd", 512, 100)

    window.new_object("Wall Blocke")
    window.set_object_image("Wall Blocke", game.object_wallpart)
    window.set_object_position("Wall Blocke", 512, 60)

    window.new_object("Wall Blockf")
    window.set_object_image("Wall Blockf", game.object_wallpart)
    window.set_object_position("Wall Blockf", 512, 20)

    window.new_object("Wall Blockg")
    window.set_object_image("Wall Blockg", game.object_wallpart)
    window.set_object_position("Wall Blockg", 512, -20)
window.set_update_delay(28)
window.set_title("Plappy Birds")
window.set_icon(game.icon_birdy)
walls4l1()













window.run()



