import pygame


def space():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_SPACE]:
        return True
    return False


def w():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_w]:
        return True
    return False


def a():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_a]:
        return True
    return False


def s():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_s]:
        return True
    return False


def d():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_d]:
        return True
    return False


def up():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_UP]:
        return True
    return False


def left():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_LEFT]:
        return True
    return False


def down():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_DOWN]:
        return True
    return False


def right():
    keys = pygame.key.get_pressed()
    if keys[pygame.K_RIGHT]:
        return True
    return False
